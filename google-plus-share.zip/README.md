Extended Share for Google+ Chrome Extension
=====================================

This Google Chrome extension will inject a link to your Google Plus profile so
that you can share your post to many social networks.

Contribute!
-----------------
Please submit your pull requests if you have anything interesting! Let me know
prior implementation :)

Follow me on [Google+](https://plus.google.com/116805285176805120365/about)

Icons
-----------------
Social Network Icon Pack by [Komodo Media, Rogie King](http://www.komodomedia.com/) is licensed under a [Creative Commons Attribution-Share Alike 3.0 Unported License](http://creativecommons.org/licenses/by-sa/3.0/).
Based on a work at [www.komodomedia.com](http://www.komodomedia.com/download/#social-network-icon-pack).
Google Plus Vector Icon by [Sean McCabe](http://boldperspective.com/2011/free-google-plus-icon-vector/)

Screenshots
-----------------
![Screenshot of the Chrome Extension](https://github.com/mohamedmansour/google-plus-extension/raw/master/screenshot/shareA.jpg)
![Screenshot of the Chrome Extension](https://github.com/mohamedmansour/google-plus-extension/raw/master/screenshot/shareB.jpg)

